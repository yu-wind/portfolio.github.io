package com.example.scheduleApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheduleAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
