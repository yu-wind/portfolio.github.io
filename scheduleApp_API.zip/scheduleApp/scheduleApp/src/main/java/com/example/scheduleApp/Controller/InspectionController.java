package com.example.scheduleApp.Controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Service.InspectionService;

@RestController
@RequestMapping("/inspection")
public class InspectionController {
    @Autowired
    InspectionService inspectionService;

    @PostMapping("/add")
    public ResponseEntity<ResponseEnvelope<List<Map<String,Object>>>> addInspection(@RequestBody Map<String,Object> inspection)//新增檢驗單
    {  
        System.out.print("Request:");
        System.out.print(inspection);
        ResponseEnvelope<List<Map<String,Object>>> responseEnvelope=inspectionService.addInspection(inspection);
        if(responseEnvelope.getStatus()=="Fail")//新增失敗
        {
            return new ResponseEntity<>(responseEnvelope,HttpStatus.BAD_REQUEST);
        }
        else//新增成功
        {
            return new ResponseEntity<>(responseEnvelope,HttpStatus.OK);
        }
    }

    @PostMapping("/list")
    public ResponseEntity<ResponseEnvelope<List<Map<String,Object>>>>  findInspectionList(@RequestBody Map<String,Object> patient)
    {
        if(patient.size()!=1||patient.get("userId")==null)//參數輸入錯誤
        {
            return new ResponseEntity<>(new ResponseEnvelope<>("Fail","參數輸入錯誤"),HttpStatus.BAD_REQUEST);
        }
        else
        {
            ResponseEnvelope<List<Map<String,Object>>> responseEnvelope=null;
            responseEnvelope=inspectionService.findInspectionList(patient.get("userId").toString());
            if(responseEnvelope.getStatus()=="Fail")
            {
                return new ResponseEntity<>(responseEnvelope,HttpStatus.BAD_REQUEST);
            }
            else
            {
                return new ResponseEntity<>(responseEnvelope,HttpStatus.OK);
            }
        }
    }

    @GetMapping("/deadline")//取得檢驗單截止日期
    public ResponseEntity<ResponseEnvelope<Map<String,Object>>> findDeadline(@RequestParam Map<String,Object> inspection)
    {
        System.out.println("1111111Request:"+inspection);
        String deadline=null;
        if(inspection.size()!=1||inspection.get("inspectionNum")==null)//參數輸入錯誤
        {
            return new ResponseEntity<>(new ResponseEnvelope<>("Fail","參數輸入錯誤"),HttpStatus.BAD_REQUEST);
        }
        deadline=inspectionService.findInspectionDeadline(inspection.get("inspectionNum").toString());
        if(deadline==null)//取得失敗
        {
            return new ResponseEntity<>(new ResponseEnvelope<>("Fail","無此檢驗單"),HttpStatus.BAD_REQUEST);
        }
        else
        {
            Map<String,Object> result=new HashMap<>();
            result.put("deadline", deadline);
            return new ResponseEntity<>(new ResponseEnvelope<>("Success",result),HttpStatus.OK);
        }
    }

}
