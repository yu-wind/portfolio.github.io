package com.example.scheduleapp.Service;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.scheduleapp.Repository.CheckinRepository;

@Service
public class CheckinService {
    @Autowired
    CheckinRepository checkinRepository;
    @Autowired
    CheckItemService checkItemService;
    @Autowired
    ScheduleService scheduleService;
    @Autowired
    PatientService patientService;

    public Map<String,Object> checkin(Map<String,Object> checkinData)//報到
    {
        Map<String,Object> result=new LinkedHashMap<>();//回傳資料
        String identifyNum=null;
        String roomNum=null;
       String patientUserId=patientService.findPatientByUserId(checkinData.get("userId").toString());//找有無此病患
        if(patientUserId==null)//無此病患
        {
            result.put("status", "Fail");
            result.put("errorMessage","無此病患");
            return result;
        }
        identifyNum=checkItemService.findIdentifyNum(checkinData.get("identifyName").toString());//用identifyName找類別編號
        if(identifyNum!=null)//有此類別
        {
            try {
                 //用userId、inspectionNum、checkItemNum找排程資料
                Map<String,Object> schedule=scheduleService.findSchedule(checkinData.get("inspectionNum").toString(), checkinData.get("checkItemNum").toString(), checkinData.get("userId").toString());
                if(schedule.get("scheduleTime")!=null)//有排程
                {
                    if(!identifyNum.equals("0005-X"))//不是X光
                    {
                        roomNum=checkinRepository.findRoom(schedule.get("scheduleTime").toString(), identifyNum, checkinData.get("userId").toString());//查詢檢查室
                    }
                    else//X光
                    {
                        roomNum="B108";
                    }
                    checkinData.put("roomNum",roomNum);
                    try {
                        checkinRepository.checkin(checkinData);//新增報到資料
                        checkinRepository.updateIsCheckin(checkinData);//更新報到狀態
                        int number=checkinRepository.findNumber(checkinData);//取得報到水號
                        result.put("status", "Success");
                        Map<String,Object> data=new HashMap<>();
                        data.put("roomNum", roomNum);
                        data.put("number", number);
                        result.put("data", data);
                        return result;
                        
                    } catch (Exception e) {
                        System.out.println("報到錯誤:"+e.toString());
                        result.put("status", "Fail");
                        result.put("errorMessage","報到失敗");
                        return result;
                    }
                    
                }
                else
                {
                    result.put("status", "Fail");
                    result.put("errorMessage","未排程");
                    return result;
                }
            } catch (Exception e) {
                System.out.println("找排程資料錯誤:"+e.toString());
                result.put("status", "Fail");
                result.put("errorMessage","報到失敗");
                return result;
            }
        }
        else{
            result.put("status", "Fail");
            result.put("errorMessage","無此類別");
            return result;
        }
    }
}
