package com.example.scheduleApp.Model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter @Setter
public class ScheduleModel {
    private String userId;
    private String identifyName;
    private String inspectionNum;
    private String checkItemNum;
    private String scheduleTime;
    private String scheduleTimeBefore;
    private String scheduleTimeAfter;
    private int reasonNum;
    private String otherReason;
    private String modifyTime;
    private String deleteTime;
    private String roomNum;
    
}
