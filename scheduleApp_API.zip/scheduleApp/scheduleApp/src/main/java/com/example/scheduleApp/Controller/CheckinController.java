package com.example.scheduleapp.Controller;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.scheduleapp.Service.CheckinService;

@RestController
public class CheckinController {
    @Autowired
    CheckinService checkinService;
    @PostMapping("/checkin")
    public ResponseEntity<Map<String,Object>> response(@RequestBody Map<String,Object> checkinData) {
        Map<String,Object> result=new HashMap<>();//回傳資料
        System.out.println("Requset:"+checkinData);

        result=checkinService.checkin(checkinData);
        if(result.get("status")=="Fail"){
            return new ResponseEntity<>(result,HttpStatus.BAD_REQUEST); //失敗
        }
        else{
            
            return new ResponseEntity<>(result,HttpStatus.OK);//成功
        }
    }
}
