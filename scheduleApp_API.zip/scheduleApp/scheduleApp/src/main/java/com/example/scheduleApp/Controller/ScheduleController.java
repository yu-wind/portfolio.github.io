package com.example.scheduleApp.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Model.ScheduleModel;
import com.example.scheduleApp.Service.ScheduleService;

@RestController
@RequestMapping("/schedule")
public class ScheduleController {
    @Autowired
    ScheduleService scheduleService;

    @PostMapping //新增排程
    public ResponseEntity<ResponseEnvelope<ScheduleModel>> addSchedule(@RequestBody ScheduleModel scheduleModel)
    {
        System.out.println("新增排程request:");
        System.out.println(scheduleModel.getUserId());
        System.out.println(scheduleModel.getIdentifyName());
        System.out.println(scheduleModel.getInspectionNum());
        System.out.println(scheduleModel.getCheckItemNum());
        System.out.println(scheduleModel.getScheduleTime());
        System.out.println(scheduleModel.getRoomNum());
        ResponseEnvelope<ScheduleModel> responseEnvelope=scheduleService.addSchedule(scheduleModel);
        if(responseEnvelope.getStatus()=="Fail")
        {
            return new ResponseEntity<>(responseEnvelope,HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(responseEnvelope,HttpStatus.OK);
    }

    @PutMapping//修改排程
    public ResponseEntity<ResponseEnvelope<ScheduleModel>> modifySchedule(@RequestBody ScheduleModel scheduleModel)
    {
        System.out.println("修改排程request:");
        System.out.println(scheduleModel.getUserId());
        System.out.println(scheduleModel.getIdentifyName());
        System.out.println(scheduleModel.getInspectionNum());
        System.out.println(scheduleModel.getCheckItemNum());
        System.out.println(scheduleModel.getScheduleTimeBefore());
        System.out.println(scheduleModel.getScheduleTimeAfter()); 
        System.out.println(scheduleModel.getReasonNum());
        System.out.println(scheduleModel.getOtherReason());
        System.out.println(scheduleModel.getModifyTime());
        String hour=scheduleModel.getModifyTime().substring(11, 13);
        System.out.println("hour"+hour);
        if(hour.equals("24"))
        {
            String str1=scheduleModel.getModifyTime().substring(0, 11);
            String str2=scheduleModel.getModifyTime().substring(13, 19);

            scheduleModel.setModifyTime(str1+"00"+str2);
        }
        System.out.println("new:"+scheduleModel.getModifyTime());
        ResponseEnvelope<ScheduleModel> responseEnvelope=scheduleService.modifySchedule(scheduleModel);
        if(responseEnvelope.getStatus()=="Fail")
        {
            return new ResponseEntity<>(responseEnvelope,HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(responseEnvelope,HttpStatus.OK);
    }
    @DeleteMapping//刪除排程
    public ResponseEntity<ResponseEnvelope<ScheduleModel>> deleteSchedule(@RequestBody ScheduleModel scheduleModel)
    {
        System.out.println("刪除排程request:");
        System.out.println(scheduleModel.getUserId());
        System.out.println(scheduleModel.getIdentifyName());
        System.out.println(scheduleModel.getInspectionNum());
        System.out.println(scheduleModel.getCheckItemNum());
        System.out.println(scheduleModel.getScheduleTimeBefore());
        System.out.println(scheduleModel.getReasonNum());
        System.out.println(scheduleModel.getOtherReason());
        System.out.println(scheduleModel.getDeleteTime());
        String hour=scheduleModel.getDeleteTime().substring(11, 13);
        System.out.println("hour"+hour);
        if(hour.equals("24"))
        {
            String str1=scheduleModel.getDeleteTime().substring(0, 11);
            String str2=scheduleModel.getDeleteTime().substring(13, 19);

            scheduleModel.setDeleteTime(str1+"00"+str2);
        }
        System.out.println("new:"+scheduleModel.getDeleteTime());
        ResponseEnvelope<ScheduleModel> responseEnvelope=scheduleService.deleteSchedule(scheduleModel);
        if(responseEnvelope.getStatus()=="Fail")
        {
            System.out.println("err:"+responseEnvelope.getErrorMessage());
            return new ResponseEntity<>(responseEnvelope,HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(responseEnvelope,HttpStatus.OK);
    }
}
