package com.example.scheduleApp.Repository;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class healthRepository {
    @Autowired
    JdbcTemplate jdbcTemplate ;

    public  Map<String,Object>  getIdentifyNum(String checkItemNum){
        String sql="select identifyNum,partNum from checkItem where checkItemNum=?";
        Map<String,Object>  data=jdbcTemplate.queryForMap(sql,checkItemNum);
        return data;
    }

    public String getHealth( Map<String,Object>  checkItem){
        String sql="select URL from health where identifyNum=? and partNum=?";
        String url=jdbcTemplate.queryForObject(sql,String.class,checkItem.get("identifyNum"),checkItem.get("partNum"));
        return url;
    }
}
