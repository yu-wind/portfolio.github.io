package com.example.scheduleapp.Repository;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CheckinRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;
    public void checkin(Map<String,Object> checkinData)//新增報到資料
    {
        String sql="Insert into checkin(inspectionNum,checkItemNum,roomNum,checkinTime) Values(?,?,?,?)"; 
        jdbcTemplate.update(sql,checkinData.get("inspectionNum"),checkinData.get("checkItemNum"),checkinData.get("roomNum"),checkinData.get("checkinTime"));
    }
    public void updateIsCheckin(Map<String,Object> checkinData)//更新報到狀態
    {
        String sql="Update schedule SET isCheckin=1 WHERE  inspectionNum=? and checkItemNum=?";
        jdbcTemplate.update(sql,checkinData.get("inspectionNum"),checkinData.get("checkItemNum"));
    }
    public int findNumber(Map<String,Object> checkinData)//報到流水號
    {
        int number=0;
        String sql="select number from checkin where inspectionNum=? and checkItemNum=?";
        number=jdbcTemplate.queryForObject(sql, Integer.class,checkinData.get(("inspectionNum")),checkinData.get("checkItemNum"));
        return number;
    }
    public String findRoom(String scheduleTime,String identifyNum,String userId)//查詢檢查室
    {
        String roomNum=null;
        String sql2="select roomNum from roomSchedule where scheduleTime=? and identifyNum=? and userId=?";
        roomNum=jdbcTemplate.queryForObject(sql2,String.class,scheduleTime,identifyNum,userId);
        return roomNum;
    }

}
