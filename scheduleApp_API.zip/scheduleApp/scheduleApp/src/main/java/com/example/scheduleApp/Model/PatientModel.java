package com.example.scheduleApp.Model;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Component
@Getter @Setter
@JsonInclude(JsonInclude.Include.NON_NULL)//當屬性值為null時不轉成JSON

public class PatientModel {
    private String userId;           //身分證
    private String name;             //姓名
    private String birth;            //出生日期
    private String gender;           //性別
    private String address;          //地址
    private String bloodType;        //血型
    private String phone;            //電話
    private String emergencyContact; //緊急聯絡人
    private String relation;         //和緊急連絡人關係
    private String emergencyPhone;   //緊急連絡人電話
    private String email;            //郵件
    private String account;          //帳號
    private String password;         //密碼
    private String uuid;             //手機識別碼
}
