package com.example.scheduleApp.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Model.PatientModel;
import com.example.scheduleApp.Repository.PatientRepository;

@Service
public class PatientService {
    @Autowired
    PatientRepository patientRepository;

    public String findPatientByUserId(String userId)//用userId找此病患 [!]
    {
        String patientUserId=null;
        try {
            patientUserId=patientRepository.findPatientByUserId(userId);
        } catch (Exception e) {
            System.out.println("錯誤:"+e.toString());
        }
        return patientUserId;
    }
//====================================================================================
    public ResponseEnvelope<PatientModel> register(PatientModel patientModel)//註冊
    {
    String patientUserId=null;
    patientUserId=findPatientByUserId(patientModel.getUserId());//找有無此病患
    if(patientUserId!=null)//已註冊
    {
        return new ResponseEnvelope<>("Fail","已註冊");
    }
    //未註冊
    try {
        patientRepository.findPatientByAccount(patientModel.getAccount());//找帳號存不存在
        return new ResponseEnvelope<>("Fail","已有此帳號");
    } 
    catch (Exception e2) {//可註冊
        try {
            patientRepository.addPatient(patientModel);//新增病患
            try {
                patientRepository.addAccount(patientModel);//新增帳號
            } 
            catch (Exception e) {
                return new ResponseEnvelope<>("Fail","新增帳號失敗");
            }
        } 
        catch (Exception e) {
            return new ResponseEnvelope<>("Fail","新增病患失敗");
        } 
        }
        return new ResponseEnvelope<>("Success");
    }
//===============================================================================================
     public String verifyAccount(String account,String password,String uuid)//驗證帳號密碼是否正確
    {
        String patientUserId=null;
        try {
            patientUserId=patientRepository.verifyAccount(account, password);
            patientRepository.changeUuId(account, password, uuid);
        } catch (Exception e) {
            System.out.println("錯誤:"+e.toString());
        }
        return patientUserId;
    }
//==========================================================
    public String getUserId(String uuid)//驗證帳號密碼是否正確
    {
        String userId=null;
      try {
       userId=patientRepository.getUserId(uuid);
      } catch (Exception e) {
        System.out.println("錯誤:"+e.toString());
      }
      return userId;
    }  


} 
