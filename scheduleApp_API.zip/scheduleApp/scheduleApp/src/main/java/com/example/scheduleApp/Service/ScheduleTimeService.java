package com.example.scheduleApp.Service;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.scheduleApp.Repository.ScheduleTimeRepository;

@Service
public class ScheduleTimeService {
    @Autowired
    ScheduleTimeRepository scheduleTimeRepository;
    public Map<String, Object> findScheduleTimeList(Map<String, Object> request)
    {
        Map<String, Object> result=new LinkedHashMap<>();//回傳資料
        LocalDateTime nowDateTime = LocalDateTime.now();//獲取當前時間
        DateTimeFormatter formatter;
        if (request.get("scheduleDate").toString().contains("/"))
        {
            formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        }
        else{

            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        }
        LocalDate nowDate = nowDateTime.toLocalDate();
        LocalDate scheduleDate = LocalDate.parse(request.get("scheduleDate").toString(),formatter);

        System.out.println("nowDate:"+nowDate);
        System.out.println("scheduleDate:"+scheduleDate);

        if(scheduleDate.compareTo(nowDate)<0)//選當天之前的日期
        {
            result.put("status", "Fail");
            result.put("errorMessage","不能選當天之前的日期");
            return result;
        }
        List<Map<String, Object>> scheduleTimeList=new ArrayList<>();//可排程時間
        try {
            String identifyNum=scheduleTimeRepository.findIdentifyNum(request.get("identifyName").toString());//找此類別編號
            String checkItemNum=scheduleTimeRepository.findCheckItemNum(request.get("checkItemNum").toString());
            try {
                List<Map<String,Object>> roomList=scheduleTimeRepository.findRoomList(identifyNum);//檢查室編號、星期幾開放、上下午開始結束時間
                try {
                    int rangetimeMin=scheduleTimeRepository.findMinRangetime(identifyNum);//找此檢查類別的最短檢查時長
                    System.out.println("rangetimeMin:"+rangetimeMin);
                    int rangetime=scheduleTimeRepository.findRangetime(request.get("checkItemNum").toString());//找此檢查項目的檢查時長
                    System.out.println("rangetime:"+rangetime);

                    List<Map<String,Object>> roomTimeList=findRoomTimeList(request.get("scheduleDate").toString(),roomList,rangetimeMin);//取得此類別每間房間有的時段
                    System.out.println("roomTimeList:"+roomTimeList);

                    List<Map<String,Object>> roomScheduleList=scheduleTimeRepository.findRoomScheduleList(identifyNum,request.get("scheduleDate").toString());//找此日期有哪些時段被使用及使用的檢查室
                    System.out.println("roomScheduleList:"+roomScheduleList);
                    int count=rangetime/rangetimeMin;//此檢查項目占幾格
                    System.out.println("count:"+count);
                    scheduleTimeList=findScheduleTimeList2(request.get("scheduleDate").toString(),roomTimeList,roomScheduleList,count,Boolean.valueOf(request.get("nearest").toString()),request.get("userId").toString());

                    int plusnum=1;
                    while(scheduleTimeList.isEmpty()&&Boolean.valueOf(request.get("nearest").toString()))
                    {
                        System.out.println("scheduleTimeList為空");
                        scheduleDate=scheduleDate.plusDays(plusnum);
                        roomTimeList=findRoomTimeList(scheduleDate.toString(),roomList,rangetimeMin);//取得此類別每間房間有的時段
                        System.out.println("roomTimeList:"+roomTimeList);
                       roomScheduleList=scheduleTimeRepository.findRoomScheduleList(identifyNum,scheduleDate.toString());//找此日期有哪些時段被使用及使用的檢查室
                        System.out.println("roomScheduleList:"+roomScheduleList);
                        scheduleTimeList=findScheduleTimeList2(scheduleDate.toString(),roomTimeList,roomScheduleList,count,Boolean.valueOf(request.get("nearest").toString()),request.get("userId").toString());
                    }
                    
                    System.out.println("scheduleTimeList:"+scheduleTimeList);
                    
                   
                } catch (Exception e) {
                    System.out.println("錯誤:"+e.toString());
                    // TODO: handle exception
                }
            } catch (Exception e) {
                result.put("status", "Fail");
                result.put("errorMessage","找此檢查室資料失敗");
                System.out.println("找此檢查室資料錯誤:"+e.toString());
                return result;
            }//end try catch
        }
        catch (Exception e) {
            result.put("status", "Fail");
            result.put("errorMessage","找此類別編號失敗");
            System.out.println("找此類別編號錯誤:"+e.toString());
            return result;
        }//end try catch
        
        result.put("status", "Success");
        result.put("data",scheduleTimeList);
        return result;
    }
    public  List<Map<String,Object>> findRoomTimeList(String scheduleDate,List<Map<String,Object>> roomList,int rangetime)//取得此類別每間房間有的時段
    {
        List<Map<String,Object>> roomTimeList = new ArrayList<>();//每間房間有的時段
        LocalTime startMorning=null,endMorning=null,startAfternoon=null,endAfternoon=null;
        try {//取得傳送過來是星期幾
            String week=null;
            if (scheduleDate.contains("/"))
            {
                SimpleDateFormat date2DayFormat = new SimpleDateFormat( "u" );
                java.util.Date trDate = new SimpleDateFormat("yyyy/MM/dd").parse(scheduleDate);
                week=date2DayFormat.format( trDate ); //取得傳送過來是星期幾
            }
            else{
                SimpleDateFormat date2DayFormat = new SimpleDateFormat( "u" );
                java.util.Date trDate = new SimpleDateFormat("yyyy-MM-dd").parse(scheduleDate);
                week=date2DayFormat.format( trDate ); //取得傳送過來是星期幾
            }
            System.out.println("week:"+week);
            Iterator<Map<String, Object>> itRoomList=roomList.iterator();  //用Iterator迭代器跑roomList
            while(itRoomList.hasNext()){
                Map<String, Object> room=itRoomList.next();
                if(room.get("week").toString().contains(week))//此檢查室有無開放此星期
                {
                    Map<String,Object> roomTime=new HashMap<>();
                    List<LocalTime> timeList= new ArrayList<>();
                    roomTime.put("roomNum", room.get("roomNum"));
                    roomTime.put("endMorning", room.get("endMorning"));
                    roomTime.put("endAfternoon", room.get("endAfternoon"));
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss"); 
                    if(room.get("startMorning")!=null)//早上
                    {
                        startMorning = LocalTime.parse(room.get("startMorning").toString(), formatter);//取得早上開始時間
                        if(room.get("endMorning")!=null)
                        {
                            endMorning = LocalTime.parse(room.get("endMorning").toString(), formatter);//取得早上結束時間
                        }
                        while(!startMorning.equals(endMorning))//不等於結束時間 
                        {       
                            timeList.add(startMorning);//存入List
                            startMorning=startMorning.plusMinutes(rangetime);//加rangetime
                           
                        }
                    }
                    if(room.get("startAfternoon")!=null)//下午
                    {
                        startAfternoon = LocalTime.parse(room.get("startAfternoon").toString(), formatter);//取得下午開始時間
                        if(room.get("endAfternoon")!=null)
                        {
                            endAfternoon = LocalTime.parse(room.get("endAfternoon").toString(), formatter);//取得下午結束時間
                        }
                        while(!startAfternoon.equals(endAfternoon))//不等於結束時間
                        {
                            timeList.add(startAfternoon);//存入List
                            startAfternoon=startAfternoon.plusMinutes(rangetime);//加rangetime  
                        }  
                    }
                    roomTime.put("timeList", timeList);
                    roomTimeList.add(roomTime);
                }
            }
        } catch (Exception e) {
            System.out.println("取得此類別每間房間有的時段錯誤:"+e.toString());
        }
        return roomTimeList;

    }
   
	public <T> List<T> objToList(Object obj, Class<T> cla){
		List<T> list = new ArrayList<T>();
    	if (obj instanceof ArrayList<?>) {
	        for (Object o : (List<?>) obj) {
	            list.add(cla.cast(o));
	        }
	        return list;
        }
        return null;
	}
   
    public  List<Map<String,Object>> findScheduleTimeList2(String scheduledate,List<Map<String,Object>> roomTimeList,List<Map<String,Object>> roomScheduleList,int count,Boolean nearest,String userId)
    {
        int jud=-1;
        LocalDateTime nowDateTime = LocalDateTime.now();//獲取當前時間
        // DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        // LocalDateTime nowDateTime = LocalDateTime.parse("2023-04-28 08:30:00", formatter2);//獲取當前時間
        
        LocalTime nowTime=nowDateTime.toLocalTime();//轉成LocalTime
        System.out.println("nowDateTime:"+nowDateTime);
        System.out.println("nowTime:"+nowTime);
        //LocalDateTime nowDateTime = LocalDateTime.now();//獲取當前時間
        LocalDate nowDate = nowDateTime.toLocalDate();
        DateTimeFormatter formatter;
        if (scheduledate.contains("/"))
        {
            formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        }
        else{

            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        }
        LocalDate scheduleDate = LocalDate.parse(scheduledate,formatter);
        List<Map<String, Object>> scheduleTimeList=new ArrayList<>();//可排程時間
        for(int roomTimeIndex=0;roomTimeIndex<roomTimeList.size();roomTimeIndex++)//一間一間跑
        {
            List<LocalTime> timeList=objToList(roomTimeList.get(roomTimeIndex).get("timeList"),LocalTime.class);
            for(int timeIndex=0;timeIndex<timeList.size();timeIndex++)//跑此檢查室有的時段
            {
                System.out.println("timeIndex::"+timeIndex);
                System.out.println("timeList.size()::"+timeList.size());
                for(int i=0;i<count;i++)//跑幾格
                {
                    if(jud==0&&i!=0)
                    {
                        break;
                    }
                    if(nowTime.plusMinutes(10).compareTo(timeList.get(timeIndex))>0 && scheduleDate.compareTo(nowDate)==0 )//時段比現在早10分鐘前不能選
                    {
                        System.out.println("-:"+nowTime.minusMinutes(10));
                        System.out.println(timeList.get(timeIndex)+"時段比現在早10分鐘前不能選");
                        jud=0;
                    }
                    else
                    {
                        jud=1;
                        for(int roomScheduleIndex=0;roomScheduleIndex<roomScheduleList.size();roomScheduleIndex++)//跑此日期有排的時段
                        {
                            if(roomScheduleList.get(roomScheduleIndex).get("roomNum").equals(roomTimeList.get(roomTimeIndex).get("roomNum"))||userId.equals(roomScheduleList.get(roomScheduleIndex).get("userId")))
                            {
                                 
                                LocalDateTime localDateTime = LocalDateTime.parse(roomScheduleList.get(roomScheduleIndex).get("scheduleTime").toString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME);
                                LocalTime scheduleTime=localDateTime.toLocalTime();//轉成LocalTime
                                localDateTime = LocalDateTime.parse(roomScheduleList.get(roomScheduleIndex).get("endTime").toString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME);
                                LocalTime endTime=localDateTime.toLocalTime();//轉成LocalTime
                                if(timeList.get(timeIndex).equals(scheduleTime))//此日期有排的時段=現在在判斷的時段
                                {
                                    System.out.println("L:"+timeIndex);   
                                    System.out.println("重複");   
                                    while(!timeList.get(timeIndex+1).equals(endTime))//此日期有排的時段的結束時間!=現在在判斷的時段的下個時段
                                    {
                                        System.out.println("重複2");
                                        if(roomTimeList.get(roomTimeIndex).get("endMorning")!=null)
                                        {
                                            DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("HH:mm:ss"); 
                                            LocalTime endMorning = LocalTime.parse(roomTimeList.get(roomTimeIndex).get("endMorning").toString(), formatter2);//取得早上結束時間
                                            if(!endTime.equals(endMorning))
                                            {
                                                System.out.println("in1:"+timeList.get(timeIndex+1)); 
                                                System.out.println("in2:"+endTime); 
                                                System.out.println("in3:"+endMorning); 
                                                // i++;
                                                // timeIndex++;
                                                System.out.println("1:"+timeIndex);  
                                                
                                            }
                                            else{
                                                break; 
                                            }
                                        }
                                       
                                        i++;
                                        timeIndex++;                          
                                    }
                                   
                                    // i++;
                                    // timeIndex++; 
                                    jud=0;
                                    break;
                                }    
                            }
                        }//end for
                    }
                    if(i!=count-1)
                    {
                        timeIndex++;
                        System.out.println("jud:"+jud);
                        System.out.println("2:"+timeIndex);                 
                    }
                }//end for
                if(jud==1)//此時段可以放
                {System.out.println("可");
                        // System.out.println("========================================");
                        // System.out.println(scheduleTimeList);
                        // System.out.println(timeList.get(timeIndex-(count-1)));
                        // System.out.println(roomTimeList.get(roomTimeIndex).get("roomNum"));
                        // System.out.println("========================================");
                    for(int j=0;j<scheduleTimeList.size();j++)//看這個時段有無在scheduleTimeList 裡
                    {
                        if(scheduleTimeList.get(j).get("time").equals(timeList.get(timeIndex-(count-1))))
                        {
                            jud=0;
                            break;
                        }
                    }
                    if(jud==1)
                    {
                        
                        Map<String, Object> result=new HashMap<>();
                        result.put("roomNum", roomTimeList.get(roomTimeIndex).get("roomNum"));
                        result.put("time", timeList.get(timeIndex-(count-1)));
                        result.put("date", scheduledate);
                        scheduleTimeList.add(result);
                        if(nearest==true)
                        {
                            break;//取最近的就好
                        }
                    }
                    
                }
            }
        }
        System.out.println(nearest.toString()+scheduleTimeList.size());
        if(nearest==true&&scheduleTimeList.size()>1)
        {
            System.out.println("in");
            formatter = DateTimeFormatter.ofPattern("HH:mm"); 
            LocalTime result=null;
            LocalTime cur=null;
            Map<String,Object> r=new HashMap<>();
            Iterator<Map<String, Object>> itScheduleTimeList=scheduleTimeList.iterator();  //用Iterator迭代器跑scheduleTimeList
            while(itScheduleTimeList.hasNext()){
                Map<String, Object> scheduleTime=itScheduleTimeList.next();
                //System.out.println("in:"+scheduleTime.get("time").toString());
                cur=LocalTime.parse(scheduleTime.get("time").toString(), formatter);
                if(result==null)
                {
                    result=cur;
                    r=scheduleTime;
                }
                else{
                    if(cur.compareTo(result)<0)//cur 比 result 早
                    {
                        result=cur;
                        r=scheduleTime;
                    }
                }
            }
            r.put("date", scheduledate);
            scheduleTimeList.clear();
            scheduleTimeList.add(r);

        }

        return scheduleTimeList;
    }
}
