package com.example.scheduleApp;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class roomService {
    @Autowired
    roomRepository repository;

    public Map<String,Object> checkin(Map<String,Object> checkinData){
        String roomnum=null;
        String number=null;
        Map<String,Object> result=new HashMap<>();
        roomnum=repository.searchRoom(checkinData.get("inspectionNum").toString(),checkinData.get("checkItemNum").toString(),checkinData.get("identifyName").toString(),checkinData.get("userId").toString());
       if(roomnum!=null)
       {
        checkinData.put("roomNum", roomnum);
        number=repository.checkin(checkinData);//新增報到資料
        result.put("number", number);
        result.put("roomNum", roomnum);
       }
        
        return result;
    }
}
