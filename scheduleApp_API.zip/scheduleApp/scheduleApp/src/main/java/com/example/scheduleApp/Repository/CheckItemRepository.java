package com.example.scheduleApp.Repository;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CheckItemRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    public String findIdentifyNum(String identifyName)//用檢驗類別名稱取得檢驗類別編號
    {
        String identifyNum=null;
        String sql="SELECT identifyNum FROM identify WHERE identifyName=?";
        identifyNum=jdbcTemplate.queryForObject(sql, String.class,identifyName);
        return identifyNum;
    }
//================================================================================================
    public String findIdentifyName(String identifyNum)//用identifyNum找檢驗類別名稱
    {
        String identifyName=null;
        String sql="SELECT identifyName FROM identify WHERE identifyNum=?";
        identifyName=jdbcTemplate.queryForObject(sql, String.class,identifyNum);
        return identifyName;
    }
//=========================================================================================
   public List<Map<String, Object>> findCheckItemList(String identifyNum)//用類別編號取得檢驗項目資料
    {
        String sql="SELECT checkItemNum,checkItemName FROM checkItem WHERE identifyNum=?";
        List<Map<String, Object>> checkItemList=jdbcTemplate.queryForList(sql,identifyNum);
        return checkItemList;
    }
//=================================================================================================
    public String findCheckItemName(String checkItemNum)//用checkItemNum找檢驗項目名稱
    {
        String checkItemName=null;
        String sql="SELECT checkItemName FROM checkItem WHERE checkItemNum=?";
        checkItemName=jdbcTemplate.queryForObject(sql, String.class,checkItemNum);
        return checkItemName;
    }
}
