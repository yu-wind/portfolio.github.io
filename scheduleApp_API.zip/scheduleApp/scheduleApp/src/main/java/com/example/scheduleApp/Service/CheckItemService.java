package com.example.scheduleApp.Service;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Repository.CheckItemRepository;

@Service
public class CheckItemService {
    @Autowired
    CheckItemRepository checkItemRepository;

    public String findIdentifyNum(String identifyName)//用檢驗類別名稱取得檢驗類別編號 [!]
    {
        String identifyNum=null;
        try {
            identifyNum=checkItemRepository.findIdentifyNum(identifyName);
        } 
        catch (Exception e) {//查詢類別編號失敗
            System.out.println("錯誤:"+e.toString());
        }
        return identifyNum;
    }
//=======================================================================================
    public String findIdentifyName(String identifyNum)//用identifyNum找檢驗類別名稱 [!]
    {
        String identifyName=null;
        try {
            identifyName=checkItemRepository.findIdentifyName(identifyNum);
        } 
        catch (Exception e) {//查類別名稱失敗
            System.out.println("錯誤:"+e.toString());
        }
        return identifyName;
    }
//==========================================================================
    public ResponseEnvelope<List<Map<String,Object>>> findCheckItemList(String identifyName)//找此類別有哪些檢查項目
    {
        String identifyNum=findIdentifyNum(identifyName);//取得檢驗類別編號
        if(identifyNum==null)//無此類別
        {
            return new ResponseEnvelope<>("Fail","無此類別");
        }
        //找此類別有哪些檢查項目
        List<Map<String, Object>> checkItemList=checkItemRepository.findCheckItemList(identifyNum);
        return new ResponseEnvelope<>("Success",checkItemList); 
    }
//============================================================================================================================
    public String findCheckItemName(String checkItemNum)//用checkItemNum找檢驗項目名稱
    {
        String checkItemName=null;
        try {
            checkItemName=checkItemRepository.findCheckItemName(checkItemNum);
        } 
        catch (Exception e) {//查檢驗項目名稱失敗
            System.out.println("錯誤:"+e.toString());
        }
        return checkItemName;
    }
}
