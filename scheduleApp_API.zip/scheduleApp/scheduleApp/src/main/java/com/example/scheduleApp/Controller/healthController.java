package com.example.scheduleApp.Controller;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Service.healthService;


@RestController
public class healthController {
    @Autowired
    healthService service;

     @GetMapping("/healthEducation")
     public ResponseEntity<ResponseEnvelope<Map<String,Object>>> response(@RequestParam Map<String,Object> checkItem) {
        System.out.println("Request:"+checkItem);
        ResponseEnvelope<Map<String,Object>> result=service.getHealth(checkItem.get("checkItemNum").toString());
        if(result.getStatus()=="Fail"){
            return new ResponseEntity<>(result,HttpStatus.BAD_REQUEST); 
        }
        else{
            
            return new ResponseEntity<>(result,HttpStatus.OK);   
        }
    }

}
