package com.example.scheduleApp.Repository;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class InspectionRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    public void addInspection(Map<String,Object> inspection)//新增檢驗單
    {
        String sql="INSERT INTO inspection (inspectionNum, userId, identifyNum,doctorNum,billingDate,deadline,isInspectionDone,isPay)"+
        " VALUES (?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql,inspection.get("inspectionNum"),inspection.get("userId"),inspection.get("identifyNum"),
                                inspection.get("doctorNum"),inspection.get("billingDate"),inspection.get("deadline"),0,0);
    }
//==========================================================================================================
    public List<Map<String,Object>> findInspectionList(String userId)//找病患有的檢驗單
    {
        String sql="Select inspectionNum,isInspectionDone,identifyNum,isPay from inspection where userId=? AND isInspectionDone=?";
        List<Map<String,Object>> inspectionList=jdbcTemplate.queryForList(sql,userId,0);
        return inspectionList;
    }
//===========================================================================================================================
    public String findInspectionDeadline(String inspectionNum)//找檢驗單截止日期
    {
        String deadline=null;
        String sql="Select deadline from inspection where inspectionNum=?";
        deadline=jdbcTemplate.queryForObject(sql,String.class,inspectionNum);
        return deadline;
    }

}
