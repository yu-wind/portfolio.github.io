package com.example.scheduleApp.Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.example.scheduleApp.Model.PatientModel;

@Repository
public class PatientRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    public String findPatientByUserId(String userId)//用userId找此病患
    {
        String patientUserId=null;
        String sql="SELECT userId FROM patient WHERE userId=?";
        patientUserId=jdbcTemplate.queryForObject(sql, String.class,userId);
        return patientUserId;
    }
//=================================================================================================
    public String findPatientByAccount(String account)//用account找有無此帳號
    {
        String patientUserId=null;
        String sql="SELECT userId FROM account WHERE account=?";
        patientUserId=jdbcTemplate.queryForObject(sql, String.class,account);
        return patientUserId;
    }
//====================================================================================================
    public void addPatient(PatientModel patientModel)//新增病患
    {
        String sql="INSERT INTO patient (userId, name, birth, gender, address,bloodType,phone,emergencyContact,relation,emergencyPhone,email)"+
        "VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql,patientModel.getUserId(),patientModel.getName(),patientModel.getBirth(),patientModel.getGender(),
             patientModel.getAddress(),patientModel.getBloodType(),patientModel.getPhone(),patientModel.getEmergencyContact(),
             patientModel.getRelation(),patientModel.getEmergencyPhone(),patientModel.getEmail());
    }
//====================================================================================================
    public void addAccount(PatientModel patientModel)//新增帳號
    {
        String sql="INSERT INTO account (userId,account,password) VALUES (?,?,?)";
        jdbcTemplate.update(sql,patientModel.getUserId(),patientModel.getAccount(),patientModel.getPassword());
    }
//================================================================================================================
    public String verifyAccount(String account,String password)//驗證帳號密碼是否正確
    {
        String patientUserId=null;
        String sql="SELECT userId FROM account WHERE account=? AND password=?";
        patientUserId=jdbcTemplate.queryForObject(sql, String.class,account,password);
        return patientUserId;
    }  
//================================================================================================

    public String getUserId(String uuid)
    {
        String patientUserId=null;
        String sql="SELECT userId FROM account WHERE lastUse=?";
        patientUserId=jdbcTemplate.queryForObject(sql, String.class,uuid);
        return patientUserId;
    } 
 
    public void changeUuId(String account,String password,String uuid){
        try{
            String sql3="select account from account where lastUse=?";
            String  findAcc=jdbcTemplate.queryForObject(sql3, String.class,uuid);
            String sql="update account set lastUse=null where account=?";
            jdbcTemplate.update(sql,findAcc);

        }catch(Exception e){
           System.out.println(e.toString());
        }     
        String sq2="update account set lastUse=? where account=? and password=?";
        jdbcTemplate.update(sq2,uuid,account,password);
    }
}
