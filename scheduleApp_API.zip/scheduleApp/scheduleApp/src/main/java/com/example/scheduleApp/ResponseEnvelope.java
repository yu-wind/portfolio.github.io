package com.example.scheduleApp;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;

@JsonInclude(JsonInclude.Include.NON_NULL)//當屬性值為null時不轉成JSON
@Getter
public class ResponseEnvelope<T> {
    private String status;
    private String errorMessage;
    private T data;
    public ResponseEnvelope(String status,T data)
    {
        this.status=status;
        this.data=data;
    }
    public ResponseEnvelope(String status,String errorMessage)
    {
        this.status=status;
        this.errorMessage=errorMessage;
    }
    public ResponseEnvelope(String status)
    {
        this.status=status;
    }
}
