package com.example.scheduleApp.Service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Repository.healthRepository;

@Service
public class healthService {
    @Autowired
    healthRepository repository;
    public ResponseEnvelope<Map<String,Object>> getHealth(String checkItemNum){
        String url=null;
        try {
            Map<String,Object>  data=repository.getIdentifyNum(checkItemNum); 
            try {
                System.out.println(data);
                url=repository.getHealth(data);
            } catch (Exception e) {
                System.out.print("查衛教錯誤:"+e.toString());
                return new ResponseEnvelope<>("Fail","查詢衛教失敗");
            }
        } catch (Exception e) {
            System.out.print("查編號、部位錯誤:"+e.toString());
            return new ResponseEnvelope<>("Fail","無此檢查項目編號");
        }
        Map<String,Object> result=new HashMap<>();
        result.put("userId", url);//回傳url
        return new ResponseEnvelope<>("Success",result);
    }
}
