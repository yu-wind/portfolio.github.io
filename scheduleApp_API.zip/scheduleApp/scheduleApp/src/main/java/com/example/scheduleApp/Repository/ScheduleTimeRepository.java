package com.example.scheduleApp.Repository;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ScheduleTimeRepository {
    @Autowired 
    JdbcTemplate jdbcTemplate;

    public String findCheckItemNum(String checkItemNum)//找此類別編號
    {
        String identifyNum=null;
        String sql="SELECT checkItemNum FROM checkItem WHERE checkItemNum=?";   
        checkItemNum=jdbcTemplate.queryForObject(sql,String.class,checkItemNum); 
        return checkItemNum;
    }
    public String findIdentifyNum(String identifyName)//找此類別編號
    {
        String identifyNum=null;
        String sql="SELECT identifyNum FROM identify WHERE identifyName=?";   
        identifyNum=jdbcTemplate.queryForObject(sql,String.class,identifyName); 
        return identifyNum;
    }
    public List<Map<String,Object>> findRoomList(String identifyNum)//找此類別檢查室資料
    {
        String sql="SELECT roomNum,week,endMorning,startMorning,endAfternoon,startAfternoon FROM room WHERE identifyNum=?";
        List<Map<String,Object>> roomList=jdbcTemplate.queryForList(sql,identifyNum);   //檢查室編號、星期幾開放、上下午開始結束時間
        return roomList;
    }
    public int findRangetime(String checkItemNum)//找此檢查項目的檢查時長
    {
        int rangetime=0;
        String sql="SELECT rangetime FROM checkItem WHERE checkItemNum=?";
        rangetime=jdbcTemplate.queryForObject(sql, Integer.class,checkItemNum);  //檢查時長
        return rangetime;
    }
    public int findMinRangetime(String indentifyNum)//找此檢查類別的最短檢查時長
    {
        int rangetimeMin=0;
        String sql="SELECT MIN(rangetime) FROM checkItem WHERE identifyNum=?";
        rangetimeMin=jdbcTemplate.queryForObject(sql, Integer.class,indentifyNum);  //檢查時長
        return rangetimeMin;
    }
    public List<Map<String,Object>> findRoomScheduleList(String identifyNum,String date )//找此日期有哪些時段被使用及使用的檢查室
    {

        String sql="SELECT roomNum,scheduleTime,endTime,userId  FROM roomSchedule WHERE identifyNum=? and scheduleTime Between ? and ?";   //這個日期、類別，有哪些檢查室在使用
        List<Map<String,Object>> scheduleRoomList=jdbcTemplate.queryForList(sql,identifyNum,date+" 00:00:00.000",date+" 23:59:59.997");
        return scheduleRoomList;
    }


}
