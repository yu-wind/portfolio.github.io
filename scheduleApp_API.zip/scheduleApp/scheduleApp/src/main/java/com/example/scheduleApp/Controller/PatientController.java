package com.example.scheduleApp.Controller;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Model.PatientModel;
import com.example.scheduleApp.Service.PatientService;

@RestController
public class PatientController {
    @Autowired
    PatientService patientService;

    @PostMapping("/register")//註冊
    public ResponseEntity<ResponseEnvelope<PatientModel>> register(@RequestBody PatientModel patientModel)
    {
        ResponseEnvelope<PatientModel> responseEnvelope=patientService.register(patientModel);
        
        if(responseEnvelope.getStatus()=="Fail")
        {
            return new ResponseEntity<>(responseEnvelope,HttpStatus.BAD_REQUEST);
        }
        else
        {
            return new ResponseEntity<>(responseEnvelope,HttpStatus.OK);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<ResponseEnvelope<Map<String,Object>>> login(@RequestBody PatientModel patientModel)
    {
        String patientUserId=null;
        patientUserId=patientService.verifyAccount(patientModel.getAccount(), patientModel.getPassword(),patientModel.getUuid());
        if(patientUserId==null)//登入失敗
        {
            return new ResponseEntity<>(new ResponseEnvelope<>("Fail","帳號密碼錯誤"),HttpStatus.BAD_REQUEST);
        }
        else//登入成功
        {
            Map<String,Object> result=new HashMap<>();
            result.put("userId", patientUserId);//回傳userId
            return new ResponseEntity<>(new ResponseEnvelope<>("Success",result),HttpStatus.OK);
        }
    }
    @PostMapping("/getUserId")
    public ResponseEntity<ResponseEnvelope<Map<String,Object>>> getUserId(@RequestBody Map<String,Object> patient)
    {
        if(patient.size()!=1||!patient.containsKey("uuid"))//參數輸入錯誤
        {
            return new ResponseEntity<>(new ResponseEnvelope<>("Fail","參數輸入錯誤"),HttpStatus.BAD_REQUEST);
        }
        String patientUserId=null;
        patientUserId=patientService.getUserId(patient.get("uuid").toString());
        if(patientUserId==null)//失敗
        {
            return new ResponseEntity<>(new ResponseEnvelope<>("Fail","找userId失敗"),HttpStatus.BAD_REQUEST);
        }
        else//成功
        {
            Map<String,Object> result=new HashMap<>();
            result.put("userId", patientUserId);//回傳userId
            return new ResponseEntity<>(new ResponseEnvelope<>("Success",result),HttpStatus.OK);
        }
    }
}
