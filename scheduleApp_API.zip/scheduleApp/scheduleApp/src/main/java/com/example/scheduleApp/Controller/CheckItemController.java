package com.example.scheduleApp.Controller;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Service.CheckItemService;

@RestController
@RequestMapping("/checkItem")
public class CheckItemController {
    @Autowired
    CheckItemService checkItemService;

    @PostMapping("/list")//用類別名稱取得檢驗項目資料
    public  ResponseEntity<ResponseEnvelope<List<Map<String, Object>>>> findCheckItemList(@RequestBody Map<String, Object> identify)
    {
        System.out.print("Request:");
        System.out.println(identify);
        if(identify.size()!=1||!identify.containsKey("identifyName"))//參數輸入錯誤
        {
            return new ResponseEntity<>(new ResponseEnvelope<>("Fail","參數輸入錯誤"),HttpStatus.BAD_REQUEST);
        }
        
        //用類別名稱取得檢驗項目資料
        ResponseEnvelope<List<Map<String, Object>>> responseEnvelope=checkItemService.findCheckItemList(identify.get("identifyName").toString());
        if(responseEnvelope.getStatus()=="Fail")//無此類別
        {
            return new ResponseEntity<>(responseEnvelope,HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(responseEnvelope,HttpStatus.OK);
    }
}
