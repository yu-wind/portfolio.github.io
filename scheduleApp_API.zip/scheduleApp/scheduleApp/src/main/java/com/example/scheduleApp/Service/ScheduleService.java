package com.example.scheduleApp.Service;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Model.ScheduleModel;
import com.example.scheduleApp.Repository.ScheduleRepository;

@Service
public class ScheduleService {
    @Autowired
    ScheduleRepository scheduleRepository;
    @Autowired
    PatientService patientService;
    public ResponseEnvelope<List<Map<String,Object>>> addCheckItem(Map<String,Object> inspection)//新增此檢驗單有的檢驗項目[!]
    {
        try {
            scheduleRepository.addCheckItem(inspection);
        } catch (Exception e) {
            System.out.println("錯誤:"+e.toString());
            return new ResponseEnvelope<>("Fail","新增檢驗項目失敗");
        }
        return new ResponseEnvelope<>("Success");
    }
//============================================================================================================
    public List<Map<String,Object>> findCheckItemList(String inspectionNum)//用inspectionNum找到此檢驗單有哪些檢驗項目(list)
    {
        List<Map<String, Object>> checkItemList=scheduleRepository.findCheckItemList(inspectionNum);
        return checkItemList;  
    }
//=========================================================================================================================
    public ResponseEnvelope<ScheduleModel> addSchedule(ScheduleModel scheduleModel)//新增排程
    {
        String patientUserId=patientService.findPatientByUserId(scheduleModel.getUserId());
        if(patientUserId==null)//無此病患
        {
            return new ResponseEnvelope<>("Fail","無此病患");
        }
        //有此病患
        try {
            //找此檢查項目的排程時間
            Map<String,Object> schedule=scheduleRepository.findSchedule(scheduleModel.getInspectionNum(),scheduleModel.getCheckItemNum(),scheduleModel.getUserId());
           //還沒排程 還沒報到 還沒檢查完
            if(schedule.get("scheduleTime")==null&&!Boolean.parseBoolean(schedule.get("isCheckin").toString())&&!Boolean.parseBoolean(schedule.get("isCheckItemDone").toString()))
            {
               
                try {
                    scheduleRepository.addScheduleTime(scheduleModel);
                    scheduleRepository.addRoomSchedule(scheduleModel);
                } catch (Exception e) {
                    return new ResponseEnvelope<>("Fail","新增失敗");
                }
            }
            else
            {
                return new ResponseEnvelope<>("Fail","已排程或檢查完");
            }
            
        } 
        catch (Exception e) {
            System.out.println("錯誤:"+e.toString());
            return new ResponseEnvelope<>("Fail","不是此病患的檢驗單或檢驗項目");
        }
        return new ResponseEnvelope<>("Success");
    }
//=========================================================================================================================
    public ResponseEnvelope<ScheduleModel> modifySchedule(ScheduleModel scheduleModel)//修改排程
    {
        System.out.println("modifyService!!!!!");
        String patientUserId=patientService.findPatientByUserId(scheduleModel.getUserId());
        if(patientUserId==null)//無此病患
        {
            System.out.println("err:無此病患");
            return new ResponseEnvelope<>("Fail","無此病患");
        }
        //有此病患
        try {
            //找此檢查項目的排程時間
            Map<String,Object> schedule=scheduleRepository.findSchedule(scheduleModel.getInspectionNum(),scheduleModel.getCheckItemNum(),scheduleModel.getUserId());
           //已排程 還沒報到 還沒檢查完
            if(schedule.get("scheduleTime")!=null&&!Boolean.parseBoolean(schedule.get("isCheckin").toString())&&!Boolean.parseBoolean(schedule.get("isCheckItemDone").toString()))
            {
               
                try {
                    if(scheduleModel.getReasonNum()==3&&scheduleModel.getOtherReason()=="")//未填寫其他原因
                    {
                        System.out.println("err:其他原因未填寫");
                        return new ResponseEnvelope<>("Fail","其他原因未填寫");
                    }
                    else if(scheduleModel.getReasonNum()!=3&&scheduleModel.getOtherReason()!="")
                    {
                        System.out.println("err:其他原因不可填寫");
                        return new ResponseEnvelope<>("Fail","其他原因不可填寫");
                    }
                    scheduleRepository.updateScheduleTime(scheduleModel);
                    try {
                        scheduleRepository.addModifyReason(scheduleModel);
                        scheduleRepository.addReasonCount(scheduleModel.getReasonNum());
                        scheduleRepository.updateScheduleTime(scheduleModel);
                        scheduleRepository.delRoomSchedule(scheduleModel);
                        scheduleRepository.modifyRoomSchedule(scheduleModel);
                    } catch (Exception e) {
                        System.out.println("錯誤:"+e.toString());
                        System.out.println("err:新增修改原因失敗");
                        return new ResponseEnvelope<>("Fail","新增修改原因失敗");
                        // TODO: handle exception
                    }
                   
                } catch (Exception e) {
                    System.out.println("錯誤:"+e.toString());
                    System.out.println("err:修改失敗");
                    return new ResponseEnvelope<>("Fail","修改失敗");
                }
            }
            else
            {
                System.out.println("err:未排程或檢查完");
                return new ResponseEnvelope<>("Fail","未排程或檢查完");
            }
        } 
        catch (Exception e) {
            System.out.println("錯誤:"+e.toString());
            System.out.println("err:不是此病患的檢驗單或檢驗項目");
            return new ResponseEnvelope<>("Fail","不是此病患的檢驗單或檢驗項目");
        }
        return new ResponseEnvelope<>("Success");
    }   
//==============================================================================================================
public ResponseEnvelope<ScheduleModel> deleteSchedule(ScheduleModel scheduleModel)//刪除排程
    {
        String patientUserId=patientService.findPatientByUserId(scheduleModel.getUserId());
        if(patientUserId==null)//無此病患
        {
            return new ResponseEnvelope<>("Fail","無此病患");
        }
        //有此病患
        try {
            //找此檢查項目的排程時間
            Map<String,Object> schedule=scheduleRepository.findSchedule(scheduleModel.getInspectionNum(),scheduleModel.getCheckItemNum(),scheduleModel.getUserId());
           //已排程 還沒報到 還沒檢查完
            if(schedule.get("scheduleTime")!=null&&!Boolean.parseBoolean(schedule.get("isCheckin").toString())&&!Boolean.parseBoolean(schedule.get("isCheckItemDone").toString()))
            {
               
                try {
                    if(scheduleModel.getReasonNum()==3&&scheduleModel.getOtherReason()=="")//未填寫其他原因
                    {
                        return new ResponseEnvelope<>("Fail","其他原因未填寫");
                    }
                    else if(scheduleModel.getReasonNum()!=3&&scheduleModel.getOtherReason()!="")
                    {
                        return new ResponseEnvelope<>("Fail","其他原因不可填寫");
                    }
                    scheduleRepository.updateScheduleTime(scheduleModel);
                    try {
                        scheduleRepository.addDeleteReason(scheduleModel);
                        scheduleRepository.addReasonCount(scheduleModel.getReasonNum());
                        scheduleRepository.delRoomSchedule(scheduleModel);
                        scheduleRepository.updateScheduleTime(scheduleModel);
    
                    } catch (Exception e) {
                        System.out.println("錯誤:"+e.toString());
                        return new ResponseEnvelope<>("Fail","新增刪除原因失敗");
                        // TODO: handle exception
                    }
                   
                } catch (Exception e) {
                    System.out.println("錯誤:"+e.toString());
                    return new ResponseEnvelope<>("Fail","刪除失敗");
                }
            }
            else
            {
                return new ResponseEnvelope<>("Fail","未排程或檢查完");
            }
        } 
        catch (Exception e) {
            System.out.println("錯誤:"+e.toString());
            return new ResponseEnvelope<>("Fail","不是此病患的檢驗單或檢驗項目");
        }
        return new ResponseEnvelope<>("Success");
    }   

}
