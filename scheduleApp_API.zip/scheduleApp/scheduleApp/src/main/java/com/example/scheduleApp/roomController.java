package com.example.scheduleApp;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class roomController {
    @Autowired
    roomService service;

    @PostMapping("/checkin")
    public ResponseEntity<ResponseEnvelope<Map<String,Object>>> response(@RequestBody Map<String,Object> data) {
        System.out.println("checkin Requset:"+data);
        Map<String,Object> result=service.checkin(data);
        if(result.get("roomNum")==null||result.get("number")==null){
            return new ResponseEntity<>(new ResponseEnvelope<Map<String,Object>>("Fail","err"),HttpStatus.BAD_REQUEST);
        }
        else{
            return new ResponseEntity<>(new ResponseEnvelope<Map<String,Object>>("Success",result),HttpStatus.OK); 
        }
    }
}