package com.example.scheduleApp.Controller;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.scheduleApp.Service.ScheduleTimeService;

@RestController
public class ScheduleTimeController {
    @Autowired
    ScheduleTimeService scheduleTimeService;
    
    @GetMapping("/scheduleTime/list")
    public  ResponseEntity<Map<String, Object>> produceTime(@RequestParam Map<String, Object> schedule)
    {
        Map<String, Object> result=new LinkedHashMap<>();//回傳資料
        // Map<String,Object> request=new HashMap();
        // request.put("scheduleDate", scheduleDate);
        // request.put("identifyName", identifyName);
        // request.put("checkItemNum", checkItemNum);
        // request.put("nearest", false);
        schedule.put("nearest", false);
        System.out.println("Request:"+schedule);
        result=scheduleTimeService.findScheduleTimeList(schedule);
        if(result.get("status")=="Fail")//無此類別
        {
            return new ResponseEntity<>(result,HttpStatus.BAD_REQUEST);//失敗
        }
        return new ResponseEntity<>(result,HttpStatus.OK);//成功
        
    }
    @GetMapping("/scheduleTime/nearest")
    public  ResponseEntity<Map<String, Object>> produceNearestTime(@RequestParam Map<String, Object> schedule)
    {
        Map<String, Object> result=new LinkedHashMap<>();//回傳資料
        // Map<String,Object> request=new HashMap();
        // request.put("scheduleDate", scheduleDate);
        // request.put("identifyName", identifyName);
        // request.put("checkItemNum", checkItemNum);
        // request.put("nearest", true);
        schedule.put("nearest", true);
        System.out.println("nearestRequest:"+schedule);
        result=scheduleTimeService.findScheduleTimeList(schedule);
        if(result.get("status")=="Fail")//無此類別
        {
            return new ResponseEntity<>(result,HttpStatus.BAD_REQUEST);//失敗
        }
        return new ResponseEntity<>(result,HttpStatus.OK);//成功
        
    }
}
