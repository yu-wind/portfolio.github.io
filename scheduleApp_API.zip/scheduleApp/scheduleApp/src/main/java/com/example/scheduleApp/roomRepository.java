package com.example.scheduleApp;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class roomRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    ObjToListMap objToListMap;
    public String searchRoom(String inspectionNum,String checkItemNum,String identifyName,String userId){
       
        String emptyRoom=null;
        String identifyNum=null;

        try {//檢驗類別編號錯誤
            String sql="SELECT identifyNum FROM identify WHERE identifyName=?";
            identifyNum=jdbcTemplate.queryForObject(sql, String.class,identifyName);    //檢驗類別編號
            System.out.println("類別編號:"+identifyNum);
                try {//select scheduleTime,isCheckin
                    String sql4="select scheduleTime,isCheckin from schedule where inspectionNum=? and checkItemNum=?"; 
                    Map<String,Object> schedule=jdbcTemplate.queryForMap(sql4,inspectionNum,checkItemNum);
                    System.out.println("schedule:::"+schedule);
                    if(schedule.get("isCheckin").toString()=="false")//未報到
                    {
                        String scheduleTime=null;
                        if(schedule.get("scheduleTime")!=null)
                        {
                            scheduleTime=schedule.get("scheduleTime").toString();
                        }
                        if(!identifyNum.equals("0005-X"))//X光
                        {
                            String sql2="select roomNum from roomSchedule where scheduleTime=? and identifyNum=? and userId=?";
                            emptyRoom=jdbcTemplate.queryForObject(sql2,String.class,scheduleTime,identifyNum,userId);
                            System.out.println("emptyRoom:::"+emptyRoom);
                        }
                        else{//X光
                            emptyRoom="B108";
                        }
                       
                    }
            } catch (Exception e1) {//select scheduleTime,isCheckin
                System.out.print("select scheduleTime,isCheckin錯誤:"+e1.toString());
            }
        } catch (Exception e) {
            System.out.println("檢驗類別編號錯誤"+e.toString());
            
            // TODO: handle exception
        }
        return emptyRoom;
    }
    public String checkin(Map<String,Object> checkinData)
    {
       String number=null;
       String sql="Insert into checkin(inspectionNum,checkItemNum,roomNum,checkinTime) Values(?,?,?,?)"; 
       jdbcTemplate.update(sql,checkinData.get("inspectionNum"),checkinData.get("checkItemNum"),checkinData.get("roomNum"),checkinData.get("checkinTime"));

       String sql2="select number from checkin where inspectionNum=? and checkItemNum=?";
       number=jdbcTemplate.queryForObject(sql2, String.class,checkinData.get(("inspectionNum")),checkinData.get("checkItemNum"));
       System.out.println("number:::"+number);

       String sql4="SELECT identifyNum FROM identify WHERE identifyName=?";
       String identifyNum=jdbcTemplate.queryForObject(sql4, String.class,checkinData.get("identifyName"));
       System.out.println("identifyNum:::"+identifyNum);
      
       String sql5="select scheduleTime from schedule where inspectionNum=? and checkItemNum=?"; 
       String scheduleTime=jdbcTemplate.queryForObject(sql5,String.class,checkinData.get("inspectionNum"),checkinData.get("checkItemNum"));
       System.out.println("scheduleTime:::"+scheduleTime);

       String sql6="Update schedule SET isCheckin=1 WHERE  inspectionNum=? and checkItemNum=?";
       jdbcTemplate.update(sql6,checkinData.get("inspectionNum"),checkinData.get("checkItemNum"));

       return number;
    }

}
