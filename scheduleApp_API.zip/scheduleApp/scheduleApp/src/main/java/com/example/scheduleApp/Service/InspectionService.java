package com.example.scheduleApp.Service;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.scheduleApp.ResponseEnvelope;
import com.example.scheduleApp.Repository.InspectionRepository;

@Service
public class InspectionService {
    @Autowired
    InspectionRepository inspectionRepository;
    @Autowired
    PatientService patientService;
    @Autowired
    CheckItemService checkItemService;
    @Autowired
    ScheduleService scheduleService;

    public ResponseEnvelope<List<Map<String,Object>>> addInspection(Map<String,Object> inspection)//新增檢驗單
    {
        String patientUserId=patientService.findPatientByUserId(inspection.get("userId").toString());//找有無此病患
        if(patientUserId==null)//無此病患
        {
            return new ResponseEnvelope<>("Fail","無此病患");
        }
        //有此病患
        String identifyNum=checkItemService.findIdentifyNum(inspection.get("identifyName").toString());//找類別編號
        if(identifyNum==null)//無此類別
        {
            return new ResponseEnvelope<>("Fail","無此類別");
        }
        //有此類別
        inspection.put("identifyNum", identifyNum);//新增 "identifyNum" key 到 inspection
        try {
            //算deadline
            //=======================================================================
            String date=inspection.get("billingDate").toString();
            //System.out.println("date:"+date);
            java.util.Date deadline = new SimpleDateFormat("yyyy/MM/dd").parse(date);
            //System.out.println(deadline);
            Calendar cDate = Calendar.getInstance();  
            cDate.setTime(deadline);
            cDate.add(Calendar.MONTH, 6);  
            deadline = cDate.getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
            //System.out.println(sdf.format(deadline));
            inspection.put("deadline", sdf.format(deadline));//新增 "deadline" key 到 inspection
           //=========================================================================
           try {
               inspectionRepository.addInspection(inspection);//新增檢驗單
               //新增檢驗單成功
               //新增此檢驗單有的檢驗項目
               ResponseEnvelope<List<Map<String,Object>>> responseEnvelope=scheduleService.addCheckItem(inspection);
               return responseEnvelope;
           } 
           catch (Exception e) {
            System.out.println("錯誤:"+e.toString());
            return new ResponseEnvelope<>("Fail","已有此檢驗單");
           }
       } 
       catch (Exception e) {//算deadline 出錯
            System.out.println("錯誤:"+e.toString());
            return new ResponseEnvelope<>("Fail","截止日期計算錯誤");
       }
    }
//=======================================================================================================================
    public ResponseEnvelope<List<Map<String,Object>>> findInspectionList(String userId)//找病患有的檢驗單
    {
        String patientUserId=null;
        String identifyName=null;
        String checkItemName=null;
        patientUserId=patientService.findPatientByUserId(userId);
        if(patientUserId==null)//無此病患
        {
            return new ResponseEnvelope<>("Fail","無此病患");
        }
        //有此病患
        List<Map<String,Object>> inspectionList=inspectionRepository.findInspectionList(userId);//找病患有的檢驗單
        if(inspectionList.isEmpty())//此病患沒有檢驗單
        {
            return new ResponseEnvelope<>("Fail","此病患沒有檢驗單");
        }
        //此病患有檢驗單
        Iterator<Map<String, Object>> it=inspectionList.iterator();//用Iterator迭代器跑inspectionList
        while(it.hasNext())//有檢驗單
        {
            Map<String, Object> inspection=it.next();//取得下一筆檢驗單資料
            try {
             
                identifyName=checkItemService.findIdentifyName(inspection.get("identifyNum").toString());//找檢驗類別名
                inspection.remove("identifyNum"); //移除 identifyNum屬性
                inspection.put("identifyName", identifyName);//新增identifyName key 到 inspection
                //找此筆檢驗單有哪些檢驗項目
                List<Map<String,Object>> checkItemList=scheduleService.findCheckItemList(inspection.get("inspectionNum").toString());
                if(!checkItemList.isEmpty())//有檢驗項目資料
                {
                    inspection.put("checkItemList", checkItemList);//新增checkItemList屬性 到 inspection
                    Iterator<Map<String, Object>> it2=checkItemList.iterator();//用Iterator迭代器跑checkItemList
                    while(it2.hasNext())//有檢查項目
                    {
                        Map<String, Object> checkItem=it2.next();//取得下一筆檢查項目資料
                        
                        try {
                            if(checkItem.get("scheduleTime")!=null)
                            {
                                String time=checkItem.get("scheduleTime").toString().replace('T',' ');
                                checkItem.put("scheduleTime", time);
                            }
                           
                            checkItemName=checkItemService.findCheckItemName(checkItem.get("checkItemNum").toString());//找檢驗項目名
                            checkItem.put("checkItemName", checkItemName);//新增checkItemName屬性 到 checkItem
                          
                        } 
                        catch (Exception e) {//查詢檢驗項目名失敗
                            System.out.println("錯誤:"+e.toString());
                            return new ResponseEnvelope<>("Fail","查詢檢驗項目名失敗");
                        }
                    }
                }
            } 
            catch (Exception e) {//查詢檢驗類別名失敗
                return new ResponseEnvelope<>("Fail","查詢檢驗類別名失敗");
            }
        }
        return new ResponseEnvelope<>("Success",inspectionList);
    }
//===========================================================================================================================
    public String findInspectionDeadline(String inspectionNum)//找檢驗單截止日期
    {
        String deadline=null;
        try {
            deadline=inspectionRepository.findInspectionDeadline(inspectionNum);
        } catch (Exception e) {
            System.out.println("錯誤:"+e.toString());
        }
        return deadline;
    }
}
