package com.example.scheduleApp.Repository;

import java.time.LocalDateTime;

import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.scheduleApp.ObjToListMap;
import com.example.scheduleApp.Model.ScheduleModel;

@Repository
public class ScheduleRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    ObjToListMap objToListMap;

    public void addCheckItem(Map<String,Object> inspection)//新增此檢驗單有的檢驗項目
    {
        //map.get(key)得到的是Object =>轉成list<String>
        List<String> checkItemList=objToListMap.objToList(inspection.get("checkItemNumList"),String.class);
        Iterator<String> it=checkItemList.iterator();//用Iterator迭代器跑checkItemList
        while(it.hasNext())//checkItemList 還有資料
        {
            String sql="INSERT INTO schedule (userId, checkItemNum, inspectionNum,scheduleTime,isCheckin,isCheckItemDone)"+
            " VALUES (?,?,?,?,?,?)";
            jdbcTemplate.update(sql,inspection.get("userId"),it.next(),inspection.get("inspectionNum"),null,0,0);
        }
    }
//====================================================================================================================
    //用inspectionNum找到此檢驗單有哪些檢驗項目(list)
    public List<Map<String,Object>> findCheckItemList(String inspectionNum)
    {
        String sql="Select checkItemNum,scheduleTime,isCheckin,isCheckItemDone from schedule where inspectionNum=? AND isCheckItemDone=?";//找檢驗單有的檢查項目
        List<Map<String,Object>> checkItemList=jdbcTemplate.queryForList(sql,inspectionNum,0);
        return checkItemList;
    }
//======================================================================================================================
    public void addScheduleTime(ScheduleModel scheduleModel)//新增排程時間
    {
        String sql="UPDATE schedule SET scheduleTime=? WHERE inspectionNum=? AND checkItemNum=? AND userId=?";
        jdbcTemplate.update(sql,scheduleModel.getScheduleTime(),scheduleModel.getInspectionNum(),scheduleModel.getCheckItemNum(),scheduleModel.getUserId());
    }
    public void updateScheduleTime(ScheduleModel scheduleModel)//更新排程時間(修改、刪除)
    {
        System.out.println("updateScheduleTime!!!!!");
        String sql="UPDATE schedule SET scheduleTime=? WHERE inspectionNum=? AND checkItemNum=? AND userId=?";
        jdbcTemplate.update(sql,scheduleModel.getScheduleTimeAfter(),scheduleModel.getInspectionNum(),scheduleModel.getCheckItemNum(),scheduleModel.getUserId());
    }
//============================================================================================================================
//房間安排
    public String findIdentifyNum(String identifyName)//找此類別編號
    {
        String identifyNum=null;
        String sql="SELECT identifyNum FROM identify WHERE identifyName=?";   
        identifyNum=jdbcTemplate.queryForObject(sql,String.class,identifyName); 
        System.out.println("T-identifyNum:"+identifyNum);
        return identifyNum;
    }
    public int findRangetime(String checkItemNum)
    {
        int rangetime=0;
        String sql="SELECT rangetime FROM checkItem WHERE checkItemNum=?";   
        rangetime=jdbcTemplate.queryForObject(sql,Integer.class,checkItemNum); 
        System.out.println("T-rangetime:"+rangetime);
        return rangetime;
    }
    public void addRoomSchedule(ScheduleModel scheduleModel)//新增房間
    {  
        try {
          
            String identifyNum=findIdentifyNum(scheduleModel.getIdentifyName());
            int rangetime=findRangetime(scheduleModel.getCheckItemNum());
            DateTimeFormatter formatter;
            if (scheduleModel.getScheduleTime().contains("/"))//xxxx/xx/xx格式
            {
                formatter = DateTimeFormatter.ofPattern("yyyy/M/d H:m:s");
            }
            else{
                formatter = DateTimeFormatter.ofPattern("yyyy-M-d H:m:s");
            }
            LocalDateTime endTime = LocalDateTime.parse(scheduleModel.getScheduleTime(), formatter).plusMinutes(rangetime);
            System.out.println("T-localDateTime:"+endTime);
          
            String sql2="INSERT INTO roomSchedule (userId, identifyNum, roomNum,scheduleTime,endTime,checkItemNum) VALUES (?,?,?,?,?,?)";
            jdbcTemplate.update(sql2,scheduleModel.getUserId(),identifyNum,scheduleModel.getRoomNum(),scheduleModel.getScheduleTime(),endTime,scheduleModel.getCheckItemNum());
        } catch (Exception e) {
            System.out.println("T-新增房間錯誤:"+e.toString());
            // TODO: handle exception
        }
       
    } 
    public void modifyRoomSchedule(ScheduleModel scheduleModel)//新增房間
    {  
        try {
        String identifyNum=findIdentifyNum(scheduleModel.getIdentifyName());
        int rangetime=findRangetime(scheduleModel.getCheckItemNum());
        DateTimeFormatter formatter;
        if (scheduleModel.getScheduleTimeAfter().contains("/"))//xxxx/xx/xx格式
        {
            formatter = DateTimeFormatter.ofPattern("yyyy/M/d H:m:s");
        }
        else{
            formatter = DateTimeFormatter.ofPattern("yyyy-M-d H:m:s");
        }
        LocalDateTime endTime = LocalDateTime.parse(scheduleModel.getScheduleTimeAfter(), formatter).plusMinutes(rangetime);
        String sql2="INSERT INTO roomSchedule (userId, identifyNum, roomNum,scheduleTime,endTime,checkItemNum) VALUES (?,?,?,?,?,?)";
        jdbcTemplate.update(sql2,scheduleModel.getUserId(),identifyNum,scheduleModel.getRoomNum(),scheduleModel.getScheduleTimeAfter(),endTime,scheduleModel.getCheckItemNum());
        } catch (Exception e) {
            System.out.println("T-更新房間錯誤:"+e.toString());
            // TODO: handle exception
        }
        
    } 
    public void delRoomSchedule(ScheduleModel scheduleModel)//刪除房間
    {  
        try {
            String identifyNum=findIdentifyNum(scheduleModel.getIdentifyName());
            String sql2="DELETE FROM roomSchedule WHERE userId=? and checkItemNum=? and identifyNum=?";
            jdbcTemplate.update(sql2,scheduleModel.getUserId(),scheduleModel.getCheckItemNum(),identifyNum);
        } catch (Exception e) {
            System.out.println("T-刪除房間錯誤:"+e.toString());
            // TODO: handle exception
        }
       
    }
//=============================================================================================================================
    //用userId、inspectionNum、checkItemNum找排程資料
    public Map<String,Object> findSchedule(String inspectionNum,String checkItemNum,String userId)
    {
        String sql="Select scheduleTime,isCheckin,isCheckItemDone from schedule where inspectionNum=? AND checkItemNum=? AND userId=? ANd isCheckin=0 AND isCheckItemDone=0";//找檢驗單有的檢查項目
        Map<String,Object> schedule=jdbcTemplate.queryForMap(sql,inspectionNum,checkItemNum,userId);
        System.out.println(schedule);
        return schedule;
    }
//=================================================================================================================================
    public void addModifyReason(ScheduleModel scheduleModel)//新增修改原因
    {
        String sql="INSERT INTO modifyReason (inspectionNum, checkItemNum, reasonNum, beforeTime,afterTime,otherReason,modifyTime) VALUES (?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql,scheduleModel.getInspectionNum(),scheduleModel.getCheckItemNum()
                ,scheduleModel.getReasonNum(),scheduleModel.getScheduleTimeBefore(),scheduleModel.getScheduleTimeAfter(),scheduleModel.getOtherReason(),scheduleModel.getModifyTime());
    }
    public void addDeleteReason(ScheduleModel scheduleModel)//新增刪除原因
    {
        String sql="INSERT INTO deleteReason (inspectionNum, checkItemNum, reasonNum, beforeTime,otherReason,deleteTime) VALUES (?,?,?,?,?,?)";
        jdbcTemplate.update(sql,scheduleModel.getInspectionNum(),scheduleModel.getCheckItemNum()
                ,scheduleModel.getReasonNum(),scheduleModel.getScheduleTimeBefore(),scheduleModel.getOtherReason(),scheduleModel.getDeleteTime());
    }
    public void addReasonCount(int reasonNum)//增加原因次數
    {
        int count=0;
        String sql1="SELECT count FROM reason WHERE reasonNum=?";//取得原因次數
        count=jdbcTemplate.queryForObject(sql1,int.class,reasonNum);
        count++;
        String sql2="UPDATE reason SET count=? WHERE reasonNum=?";//更新原因次數
        jdbcTemplate.update(sql2,count,reasonNum);
    }
}
